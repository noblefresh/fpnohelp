@component('mail::message')
# BOT UNKNOWN QUESTION

Master, I have an unknown question, kindly help me with an answer please.

@component('mail::button', ['url' => ''])
Check Here
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
