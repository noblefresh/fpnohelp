@extends('template.layouts')
@section('content')
    <section id="home" class="hero-section dtr-py-8 hero-default-bg bg-lue color-dark">
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-md-8">
                    This is just a taste page (Privacy Policy) hasdgs sghdshd dhsgdha ajhdjsdg sndjsdjhad sdjhsjdhg sdjhshda djhasdjhad shdj
                </div>
            </div>
        </div>
    </section>

    @include('template.footer')
@endsection