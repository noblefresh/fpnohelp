

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        
        <div class="row p-4">
            <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-sm-6 col-md-3">
                <div class="card shadow">
                  <img class="card-img-top" src="<?php echo e(asset('/storage/postImages/'.$post->image)); ?>" style="width:100%">
                  <div class="card-body">
                    <h4 class="text-center"><?php echo e($post->title); ?></h4><br>
                    <p class="card-text badge badge-dark">Author: <?php echo e($post->author); ?></p>
                  </div>
                  <div class="card-foote">
                    
                    <a href="<?php echo e(url('/viewpost/'.$post->id)); ?>" class="btn btn-primary shadow" style="width: 100%;">View Post</a>
                  </div>
                </div>
            </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\funia\resources\views/users/userblog.blade.php ENDPATH**/ ?>