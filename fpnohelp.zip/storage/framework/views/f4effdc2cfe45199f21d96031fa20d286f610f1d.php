

<?php $__env->startSection('content'); ?>


    <div class="content-wrapper pt-4">
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card">
                                <img class="card-img-top" src="<?php echo e(asset('/storage/postImages/' . $posts->image)); ?>"
                                    alt="blog_post_image">
                                
                                <div class="card-body">
                                    <h4 class="text-center"><?php echo e($posts->title); ?></h4>
                                    <p><?php echo $posts->content; ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>


                    <div class="col-md-4">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <h5 class=""><b>Related Post</b></h5>
                                </div>
                            </div>
                            <div class="row">
                                <?php
                                use App\Models\blog;
                                $blog = blog::inRandomOrder()->get();
                                ?>
                                <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-12 col-sm-12 col-md-12">
                                        <div class="card shadow">
                                            <img class="card-img-top"
                                                src="<?php echo e(asset('/storage/postImages/' . $post->image)); ?>"
                                                style="width:100%">
                                            <div class="card-body">
                                                <a href="<?php echo e(url('/viewpost/' . $post->id)); ?>">
                                                    <h5 class="text-center"><?php echo e($post->title); ?></h5>
                                                </a>
                                                <?php
                                                $string = $post->content;
                                                if (strlen($string) > 150) {
                                                    $stringCut = substr($string, 0, 200);
                                                    $endPoint = strrpos($stringCut, '');
                                                    $string = $endPoint ? substr($stringCut, 0, $endPoint) : substr($stringCut, 0);
                                                }
                                                ?>
                                                <span><?php echo $string; ?>... <a
                                                        href="<?php echo e(url('/viewpost/' . $post->id)); ?>"
                                                        style="color:rgb(182, 178, 178)">read more</a></span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    </section>
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fpnohelp\resources\views/admin/blogview.blade.php ENDPATH**/ ?>