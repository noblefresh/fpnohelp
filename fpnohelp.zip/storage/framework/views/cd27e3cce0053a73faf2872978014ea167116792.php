

<!DOCTYPE html>
<html lang="en" class=" ">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>FPNOHELP - Exam Past Question, Support, Solution Article, Smart Bot</title>
  <meta property="og:url"                content="https://fpnohelp.com" />
  <meta property="og:type"               content="Educational Platform"/>
  <meta property="og:title"              content="FPNOHELP - Exam Past Question, Support, Solution Artcile, Smart Bot"/>
  <meta property="og:description"        content="Easy learning with quick response and helpful articles"/>
  <meta property="og:image"              content="/images/icon.png" />
  


  <!-- App Icons -->
  <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(asset('images/icon.png')); ?>">
  <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset('images/icon.png')); ?>">
  <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset('images/icon.png')); ?>">
  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('images/icon.png')); ?>">
  <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(asset('images/icon.png')); ?>">
  <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset('images/icon.png')); ?>">
  <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset('images/icon.png')); ?>">
  <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('images/icon.png')); ?>">
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('images/icon.png')); ?>">
  <link rel="icon" type="image/png" sizes="192x192" href="<?php echo e(asset('images/icon.png')); ?>">
  <link rel="icon" type="image/png" sizes="512x512" href="<?php echo e(asset('images/icon.png')); ?>">
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('images/icon.png')); ?>">
  <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset('images/icon.png')); ?>">
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/icon.png')); ?>">
  <link rel="manifest" href="assets/images/icons/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="assets/images/icons/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">


  <link href="assets/css/preloader.css" type="text/css" rel="stylesheet" media="screen" />

  <link href="modules/materialize/materialize.min.css" type="text/css" rel="stylesheet" media="screen" />
  <link href="modules/fonts/mdi/appicon/appicon.css" type="text/css" rel="stylesheet" media="screen" />
  <link href="modules/fonts/mdi/materialdesignicons.min.css" type="text/css" rel="stylesheet" media="screen" />
  <link href="modules/perfect-scrollbar/perfect-scrollbar.css" type="text/css" rel="stylesheet" media="screen" />
  <link href="assets/css/style.css" type="text/css" rel="stylesheet" media="screen" id="main-style" />
  

</head>
<!-- END HEAD -->

<!-- BEGIN BODY -->


<body class=" menu-full  ishome  isfullscreen  html"  data-header="light" data-footer="dark"  data-header_align="center"  data-menu_type="left" data-menu="light" data-menu_icons="on" data-footer_type="left" data-site_mode="light" data-footer_menu="show" data-footer_menu_style="light"  >
    
  

<!--  SIDEBAR - END -->
<div class="content-area">




  
<img src="" alt="">


<h1 class="white-text center welcome-logo index-welcome" style="margin-bottom: 30px">
  <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" style="width: 150px"><br>

FPNO HELP
</h1>

<div class="fullfixed index-carousel">
  
  <div class="carousel carousel-fullscreen carousel-slider">

        <a class="carousel-item" href="#carousel-slide-0!">
      <div class="bg" style="background-image: url('images/slide-1.jpg')"></div>
      <div class="item-content center-align white-text">

                  <h3>Another vision for students quick response</h3>
        
      </div>
      
      </a>
        <a class="carousel-item" href="#carousel-slide-1!">
      <div class="bg" style="background-image: url('images/slide-2.jpg')"></div>
      <div class="item-content center-align white-text">

                  <h3>A free access from your comfort zone</h3>
        
      </div>
      
      </a>
        <a class="carousel-item" href="#carousel-slide-2!">
      <div class="bg" style="background-image: url('images/slide-3.jpg')"></div>
      <div class="item-content center-align white-text">

                  <h3>Campus made easy platform</h3>
        
      </div>
      
      </a>
        <a class="carousel-item" href="#carousel-slide-3!">
      <div class="bg" style="background-image: url('images/slide-4.jpg')"></div>
      <div class="item-content center-align white-text">

                  <h3>Enjoy learning at all times</h3>
        
      </div>
      
      </a>
      </div></div>

        <div class="wave-bg">
          <div></div>
        </div>


<div class="center index-start">
  <a href="<?php echo e(route('register')); ?>" class='waves-light btn-large' style="background-color: #3490dc">  Get Started
  </a>
  <a href="<?php echo e(route('login')); ?>" class='login-link'>Already a member? Sign In</a>  <a href="<?php echo e(route('register')); ?>" class='register-link'>Register</a>

</div>



</div><!--.content-area-->


<script src="assets/js/pwa.js"></script>

<!-- LOAD FILES AT PAGE END FOR FASTER LOADING -->

<!-- CORE JS FRAMEWORK - START -->
<script src="modules/jquery/jquery-2.2.4.min.js"></script>
<script src="modules/materialize/materialize.js"></script>
<script src="modules/perfect-scrollbar/perfect-scrollbar.min.js"></script>

<!-- CORE JS FRAMEWORK - END -->


<!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - START -->
<script src="assets/js/common.js"></script><!-- OTHER SCRIPTS INCLUDED ON THIS PAGE - END -->


<!-- CORE TEMPLATE JS - START -->


<!-- END CORE TEMPLATE JS - END -->


<script src="assets/js/preloader.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\fpnohelp\resources\views/welcome.blade.php ENDPATH**/ ?>