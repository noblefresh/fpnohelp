<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-center align-items-center bg-primary cover">
    <div class="card shadow-lg p-2">
        <div class="m-2">
            <?php if(session('resent')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                </div>
            <?php endif; ?>
        </div>
        <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>
            <div class="card-body px-3 flex-column">
                <div class="text-center">
                    <img src="<?php echo e(asset('images/bot-pana.png')); ?>" class="w-50">
                    <div style="font-weight:700;font-size: 20px;color: rgb(143, 147, 150);">Verify Your Email Address <i class="fas fa-hand"></i></div>
                    <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

                    <?php echo e(__('If you did not receive the email')); ?> 
                    <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                        <?php echo csrf_field(); ?>
                        <br> <button type="submit" class="nput bg-primary py-2 w-100 mt-4 text-center shadow" style="color: azure;border: none;"><?php echo e(__('Click here to request another')); ?></button>
                    </form>
                </div>
                
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fpnohelp\resources\views/auth/verify.blade.php ENDPATH**/ ?>