<footer class="footer-details mb-0">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <div class="mt-2">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo" style="width: 100px">
          </div>
          <div class="footIcon" style="">
            
            <span class="pt-1 d-block"><a href="mailto:info@fpnohelp.com"><i class="fas fa-envelope pr-2"></i> info@fpnohelp.com</a><span>
            <span class="pt-1 pb-2 d-block"><a href=""><i class="fas fa-map-marker-alt pr-2"></i> FFPNO NEKEDE, OWERRI, IMO STATE NIG.</a><span>
          </div>
        </div>
      </div>
    </div>
    <div class="developer-signature mb-0 bg-primary">
      <p class="pt-3 pb-5 mb-0 text-light">
        © Copyright FPNO HELP. All rights reserved. 
      </p>
    </div>
</footer>
  
<div class="footer-menu circular">
    <ul>
        <li>
            <a data-widget="pushmenu" href="#" role="button"> <i class="fas fa-align-left"></i>
                <span>More</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('userblog')); ?>"> <i class="far fa-newspaper"></i>
                <span>Article</span>
            </a>
        </li> 
        <li class="bg-drk rounde">
            <a href="<?php echo e(route('home')); ?>"> <i class="fas fa-house-damage"></i>
                <span>Home</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('lastyearpq')); ?>"> <i class="fas fa-copy"></i>
                <span>Past-Q</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('smartbot')); ?>"> <i class="fas fa-robot"></i>
                <span>Smart Bot</span>
            </a>
        </li>
    </ul>
</div><?php /**PATH C:\xampp\htdocs\fpnohelp\resources\views/layouts/footer.blade.php ENDPATH**/ ?>