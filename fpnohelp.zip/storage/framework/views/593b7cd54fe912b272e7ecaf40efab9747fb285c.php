<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="format-detection" content="telephone=no">
<meta name="theme-color" content="#0089F3" />
<title>FUNAI Exams Past Questions</title>
<meta property="og:url"                content="https://caphilsenterprise.com" />
<meta property="og:type"               content="Educational Platform"/>
<meta property="og:title"              content="FUNAI Exams Past Questions"/>
<meta property="og:description"        content="Get Access to FUNAI Past Questions Here!! "/>
<meta property="og:image"              content="/images/icon.png" />

<!-- FAVICON FILES -->
<link href="<?php echo e(asset('images/icon.png')); ?>" rel="shortcut icon">

<!-- GOOGLE WEB FONT -->
<link href="https://fonts.googleapis.com/css?family=Oxygen:300,400,700&display=swap" rel="stylesheet">

<link href="<?php echo e(asset('fontawesome-free-5/css/all.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('fontawesome-free-5/css/brands.css')); ?>" rel="stylesheet" type="text/css">

<!-- CSS FILES -->
<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/fonts/iconfont.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/swiper.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/venobox.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/color-1.css')); ?>">

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</head>
<body>
<!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>
<script>(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div id="dtr-wrapper" class="clearfix"> 

    
<main class="main">
    <?php echo $__env->yieldContent('content'); ?>
</main>



<!-- Success Modal -->
<div class="modal fade" id="sucessModal" tabindex="-1" role="dialog" aria-labelledby="sucessModal" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
        <div class="modal-body">
            <div class="text-center">
                <i class="fas fa-check-circle text-success" style="font-size:3.0em;"></i>
                <p class="modalMsg"></p>
            </div>
        </div>
    </div>
    </div>
</div>

<!-- Error Modal -->
<div class="modal fade" id="errorModal" tabindex="-1" role="dialog" aria-labelledby="errorModal" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
        <div class="modal-body">
            <div class="text-center">
                <i class="fas fa-times text-danger" style="font-size:3.0em;"></i>
                <p class="errorModalMsg"></p>
            </div>
        </div>
    </div>
    </div>
</div>
<!-- Success Modal End -->
<?php if(session('success')): ?>
<script>
    $('#sucessModal').on('show.bs.modal', function(){
        $('.modalMsg').text("<?php echo e(session('success')); ?>");
    });
    $('#sucessModal').modal('show');
</script>
<?php endif; ?>

<?php if(session('error')): ?>
<script>
    $('#errorModal').on('show.bs.modal', function(){
        $('.errorModalMsg').text("<?php echo e(session('error')); ?>");
    });
    $('#errorModal').modal('show');
    // alert('Thanks for subscribing!');
</script>
<?php endif; ?>

<script type="text/javascript">
    $(document).ready(function(){
        // alert('ok');
    });
    
</script>

<style>
    .invalid-feedback{
        color: black !important;
    }
</style>
    
</div>
<!-- #dtr-wrapper ends --> 
<!-- JS FILES --> 


<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script> 
<script src="<?php echo e(asset('assets/js/jquery.easing.js')); ?>" type="text/javascript"></script> 
<script src="<?php echo e(asset('assets/js/swiper.min.js')); ?>" type="text/javascript"></script> 
<script src="<?php echo e(asset('assets/js/venobox.min.js')); ?>" type="text/javascript"></script> 
<script src="<?php echo e(asset('assets/js/select2.min.js')); ?>" type="text/javascript"></script> 
<script src="<?php echo e(asset('assets/js/jquery.validate.min.js')); ?>" type="text/javascript"></script> 
<script src="<?php echo e(asset('assets/js/jquery.form.js')); ?>" type="text/javascript"></script> 
<script src="<?php echo e(asset('assets/js/wow.min.js')); ?>" type="text/javascript"></script> 
<script src="<?php echo e(asset('assets/js/custom.js')); ?>" type="text/javascript"></script> 
<script>
	// wow animations
	if( $(window).outerWidth() >= 767 ) {
		new WOW().init({
			mobile: false,
		});
	}
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\funia\resources\views/template/layouts.blade.php ENDPATH**/ ?>