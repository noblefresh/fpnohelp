

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        
        <?php if(count($pastquestions) < 1): ?>
          <div class="row">
            <div class="col-12 col-sm-12 col-md-12">
              <div class="text-center" style="margin-top: 70px">
                <h5>No Record Found! <i class="fas fa-exclamation-circle"></i></h5>
              </div>
            </div>
          </div>
        <?php else: ?>
        <div class="row">
            <?php $__currentLoopData = $pastquestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-sm-6 col-md-3 pt-4">
                <div class="card shadow">
                  <span class=" badge badge-primary"><?php echo e($pq->department->department); ?> (<?php echo e($pq->year); ?>) (<?php echo e($pq->level); ?> L)</span>
                  <div class="card-body">
                    <img src="<?php echo e(asset('/storage/pastquestionImages/'.$pq->image)); ?>" style="width:100%">
                    <span class="badge badge-dark">Course Code: <?php echo e($pq->coursecode); ?></span>
                    
                    <?php if($pq->semester == '1'): ?>
                    <span class=" badge badge-primary">1st Semester</span>
                    <?php else: ?>
                    <span class=" badge badge-primary">2nd Semester</span>
                    <?php endif; ?>
                  </div>
                  <div class="card-foote">
                    <a href="<?php echo e(url('/storage/pastquestionImages/'.$pq->image)); ?>" download class="btn btn-primary shadow" style="width: 50%">Download</a>
                    <a href="<?php echo e(url('/deletepastquestion/'.$pq->id)); ?>" class="btn btn-danger shadow" style="width: 50%; float:right">Delete</a>
                  </div>
                </div>
            </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
      </div>
        <?php endif; ?>
    </section>
  </div>
  <!-- /.content-wrapper -->

  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fpnohelp\resources\views/admin/search_result.blade.php ENDPATH**/ ?>