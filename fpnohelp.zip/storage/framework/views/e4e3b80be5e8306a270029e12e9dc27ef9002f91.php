

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12">
            <h6 class="m-0 text-dark text-bold">All Users</h6>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
            <?php $__currentLoopData = $allusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($show->level < 3): ?>
            <div class="col-md-3">
              <!-- Profile Image -->
                <div class="card card-primary card-outline shadow">
                    <div class="card-body box-profile activityDi">
                    <div class="text-center">
                        <?php if(count($profilepicture) > 0): ?>
                            <?php $__currentLoopData = $profilepicture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($show->id == $picture->userid): ?>
                            <img class="profile-user-img img-fluid img-circle"
                            src="<?php echo e(asset('/userImage/'.$picture->image)); ?>"
                            alt="User profile picture">
                            <?php else: ?>
                            <img class="profile-user-img img-fluid img-circle"
                            src="<?php echo e(asset('/userImage/default.png')); ?>"
                            alt="User profile picture">
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
    
                    <h3 class="profile-username text-center"><?php echo e($show->name); ?></h3>
    
                    <p class="text-mute text-center"><?php echo e($show->email); ?></p>
                    <ul class="list-group list-group-unbordered mb-3">
                        <li class="list-group-item" style="background-color:  ">
                            <b>User ID</b> <a class="float-right"><?php echo e($show->id); ?></a>
                        </li>
                        <li class="list-group-item" style="background-color:  ">
                            <b>Dept.</b> <a class="float-right"><?php echo e(isset($show->department->department) ? $show->department->department : 'null'); ?></a>
                        </li>
                        <li class="list-group-item" style="background-color:  ">
                            <b>Level</b> <a class="float-right"><?php echo e($show->userlevel); ?> Student</a>
                        </li>
                        <li class="list-group-item" style="background-color:  ">
                            <b>Registered On</b> <a class="float-right"><?php echo e(date('d M, Y', strtotime($show->created_at))); ?></a>
                        </li>
                    </ul>
                    <?php if(Auth::user()->level == 2): ?>
                    
                    <?php else: ?>
                        <?php if(Auth::user()->level > 2): ?>
                            <?php if($show->level == 2): ?>
                            <a href="#"  class="btn btn-dark" style="width: 45%"><small>Base Admin</small></a>
                            <a href="<?php echo e(url('/remove_as_admin/'.$show->id)); ?>"  class="btn btn-danger"><small>Remove Admin</small></a>
                            <?php else: ?>
                            <a href="<?php echo e(url('/make_user_admin/'.$show->id)); ?>"  class="btn btn-primary w-100"><b>Make this User Admin</b></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                    </div>
              </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- /.col -->
          </div>
          <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fpnohelp\resources\views/admin/allusers.blade.php ENDPATH**/ ?>