

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card mt-4 shadow">
                        <div class="card-header">
                            <strong class="card-tite">Subscribers Details</strong>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <th>Year</th>
                                        <th>Department</th>
                                        <th>Level</th>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>Amount</th>
                                        <th>Date</th>
                                    </thead>
                                    <tbody>
                                        <?php
                                            use App\Models\department;
                                        ?>
                                        <?php $__currentLoopData = $paidPQ; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paidPQs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($paidPQs->year); ?></td>
                                            <?php
                                                $getDept = department::where('id',$paidPQs->user2->deptid)->get();
                                            ?>
                                            <?php $__currentLoopData = $getDept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($item->department); ?></td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($paidPQs->user2->userlevel); ?> level</td>
                                            <td><?php echo e($paidPQs->user2->name); ?></td>
                                            <td><?php echo e($paidPQs->user2->email); ?></td>
                                            <td>&#8358;200.00</td>
                                            <td><?php echo e(date('d M, Y', strtotime($paidPQs->user2->created_at))); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>  
        </div>
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fpnohelp\resources\views/admin/allpqsubscribed.blade.php ENDPATH**/ ?>