
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-wrapper">
        <section class="content">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-md-6 mt-4 card">
                        <form method="post" action="<?php echo e(url('/saveaccountsetup')); ?>">
                            <?php echo csrf_field(); ?>
                          <div class="modal-body">
                              <H4 class="mb-3">Account Setup</H4>
                              <div class="row">
                                <div class="col-md-6">
                                  <div class="form-group">
                                    <label>Faculty</label>
                                    <select class="form-control getDepartment" id="">
                                      <option value="">Select Your Faculty</option>
                                      <?php
                                          use App\Models\faculty;
                                          $getfaculty = faculty::orderBy('id','DESC')->get();
                                      ?>
                                      <?php $__currentLoopData = $getfaculty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($faculty->id); ?>"><?php echo e($faculty->faculty); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                  </div>
                                </div>
                                <div class="col-md-6">
                                  <div class="form-group">
                                    <label>Department</label>
                                    <select class="form-control department" id="" name="deptid" required>
                                      
                                    </select>
                                  </div>
                                </div>
                                <div class="col-md-6">
                                  <div class="form-group">
                                      <label>Level</label>
                                      <select class="form-control" name="level" required>
                                          <option value="">Select Level</option>
                                          <option value="100">ND I</option>
                                          <option value="200">ND II</option>
                                          <option value="300">HND I</option>
                                          <option value="400">HND II</option>
                                      </select>
                                  </div>
                                </div>
                                <div class="col-md-6">
                                  <div class="form-group">
                                      <label>Level</label>
                                      <select class="form-control" name="program" required>
                                        <option value="">Select Program</option>
                                        <option value="Morning">Morning</option>
                                        <option value="Evening">Evening</option>
                                        <option value="Weekend">Weekend</option>
                                      </select>
                                  </div>
                                </div>
                              </div>
                          </div>
                          <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Save setup</button>
                          </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fpnohelp\resources\views/users/setup.blade.php ENDPATH**/ ?>