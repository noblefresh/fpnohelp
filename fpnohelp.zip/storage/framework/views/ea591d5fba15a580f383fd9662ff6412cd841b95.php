
<?php $__env->startSection('content'); ?>
    <section id="home" class="hero-section dtr-py-8 hero-default-bg bg-blue color-white">
        <div class="container">
            <div class="row align-items-center"> 
                <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 text-right wow fadeInRight" data-wow-delay="0.4s" > 
                    
                    <!-- Image --> 
                    
                    <img src="<?php echo e(asset('/storage/postImages/'.$item->image)); ?>" alt="video-bg" style="border-radius: 10px">
                    
                </div>

                <div class="col-12 col-md-6 dtr-sm-mb-30px"> 
                    
                    <!-- Heading -->
                    <h1 class="dtr-mb-4 wow fadeInUp" data-wow-delay="0.4s">
                       <?php echo e($item->title); ?></h1>
                    
                    <!-- Text -->
                    <p class="dtr-mb-5 color-white-muted wow fadeInUp w-75" data-wow-delay="0.6s"> 
                       By: <?php echo e($item->author); ?></p>
                        
                    <!-- button -->
                    <div class="dtr-btn wow
                     fadeInUp" data-wow-delay="0.8s"> <a href="#readmore">Read More<span><i class="fas fa-arrow-down" aria-hidden="true"></i></span> </a> </div>
                </div> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <section id="readmore" class="pt-5 pb-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo $item->content; ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="col-md-4">
                    <?php
                    use App\Models\blog;
                    $blog= blog::orderBy('id','ASC')->limit(2)->get();
                    ?>
                    <!-- slide 1 starts -->
                    <div class="row">
                        <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-12">
                            <div class="swiper-slide">
                                <div class="dtr-post-carousel-item">
                                    <div class="dtr-post-carousel-content"> <img src="<?php echo e(asset('/storage/postImages/'.$post->image)); ?>" alt="image">
                                        <div class="dtr-post-carousel-entry-content"> 
                                            
                                            <h5><a href="<?php echo e(url('/blog/'.$post->id)); ?>"><?php echo e($post->title); ?></a></h5>
                                        </div>
                                        <div class="dtr-post-carousel-meta">
                                            <ul class="dtr-meta">
                                                <li class="dtr-meta-author"><?php echo e($post->author); ?></li>
                                                <li class="dtr-meta-date"><?php echo e(date('d/m/y', strtotime($post->created_at))); ?></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- slide 1 ends --> 
                </div>
            </div>
        </div>
    </section>

    <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\funia\resources\views/blog.blade.php ENDPATH**/ ?>