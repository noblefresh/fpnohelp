
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-wrapper">
        <section class="content">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-md-6 mt-4 text-center order-sm-1 mt-lg-5">
                        <img src="<?php echo e(asset('images/mobile-app.png')); ?>" style="width: 200px">
                    </div>
                    <div class="col-md-6 order-sm-2">
                        <div class="mobile-app-content p-3">
                            <h1><strong>You can grab it right now</strong></h1>
                            <p>Make it more easy for you</p>
                            <div class="text-center">
                                <a href="" class="d-inline pr-1">
                                    <img src="<?php echo e(asset('images/playstore.png')); ?>" style="width: 45%">
                                </a>
                                <a href="" class="d-inline pl-1">
                                    <img src="<?php echo e(asset('images/appstore.png')); ?>" style="width: 45%">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fpnohelp\resources\views/users/mobile.blade.php ENDPATH**/ ?>