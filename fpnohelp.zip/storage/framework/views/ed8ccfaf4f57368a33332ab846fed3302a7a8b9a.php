<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-center align-items-center bg-primary cover">
    <div class="card shadow-lg p-2">
        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
            <div class="card-body px-3 flex-column">
                <div class="text-center">
                    <img src="<?php echo e(asset('images/bot-pana.png')); ?>" class="w-50">
                    <div style="font-weight:700; font-size: 30px; color: rgb(143, 147, 150);">Get Started</div>
                    
                </div>
                <div class="input py-2 w-100 my-2 my-sm-3 position-relative shadow-sm">
                    <i class="fa fa-user position-absolute mt-2 ml-2"></i>
                    <input type="text" id="name" class="w-100 py-1 name <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus placeholder="Fullname">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="invalid-feedback pl-3" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="input py-2 w-100 my-2 my-sm-3 position-relative shadow-sm">
                    <i class="fa fa-user position-absolute mt-2 ml-2"></i>
                    <input type="text" id="email" class="w-100 py-1 name <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="E-Mail Address">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="invalid-feedback pl-3" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="input py-2 w-100 my-2 my-sm-3 position-relative shadow-sm">
                    <i class="fa fa-lock position-absolute mt-2 ml-2"></i>
                    <span class="far fa-eye position-absolute mt-2 shn eye d-none"></span>
                    <span class="far fa-eye-slash position-absolute shn1 mt-2 eye d-none"></span>
                    <input type="password" id="password" class="w-100 py-1 password show1 name <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password" placeholder="Password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="invalid-feedback pl-3" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="input py-2 w-100 my-2 my-sm-3 position-relative shadow-sm">
                    <i class="fa fa-lock position-absolute mt-2 ml-2"></i>
                    <span class="far fa-eye shw position-absolute mt-2 eye d-none"></span>
                    <span class="far fa-eye-slash shw1 position-absolute mt-2 eye d-none"></span>
                    <input type="password" class="w-100 py-1 password show name" id="password-confirm" name="password_confirmation" required autocomplete="new-password" placeholder="Confirm Password">
                </div>
                <button class="nput bg-primary py-2 w-100 mt-4 text-center shadow" style="color: azure;border: none;">
                    REGISTER
                </button>
                <div class="text-center py-2" style="text-decoration: underline;">
                    Already have an account? <a href="<?php echo e(route('login')); ?>">Login here</a> 
                </div>
            </div>
        </form>
    </div>
</div>



<script>
    $('.eye').on('click',function () {
        $(this).siblings('span').toggleClass('d-none');
        $(this).toggleClass('d-none');
        if($(this).siblings('input').attr('type') == 'password'){
            $(this).siblings('input').attr('type','text')
        }else{
            $(this).siblings('input').attr('type','password')
        }
    })
    $('.show').on('keyup',function () {
        if($(this).val() != ''){ 
            if($('.shw1').css('display') == 'none'){
                $('.shw').removeClass('d-none')
            }
        }else{
            $('.shw').addClass('d-none')
            $('.shw1').addClass('d-none')
            $(this).attr('type','password')
        }
    })
    $('.show1').on('keyup',function () {
        if($(this).val() != ''){ 
            if($('.shn1').css('display') == 'none'){
                $('.shn').removeClass('d-none')
            }
        }else{
            $('.shn').addClass('d-none')
            $('.shn1').addClass('d-none')
            $(this).attr('type','password')
        }
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fpnohelp\resources\views/auth/register.blade.php ENDPATH**/ ?>