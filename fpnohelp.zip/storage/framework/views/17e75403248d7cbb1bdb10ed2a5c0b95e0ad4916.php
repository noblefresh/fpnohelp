

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<?php
use App\Models\pastquestion;
?>
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12">
                    <?php
                    $getMyPQ = pastquestion::where('deptid',Auth::user()->deptid)
                    ->where('level',Auth::user()->userlevel)
                    ->where('year',$year->year)->get();
                    
                    $subscribed = false;
                    foreach (Auth::user()->QuestionAccess as $subscription) {
                        if ($subscription->year == $year->year) {
                            $subscribed = true;
                        }
                    }
                    ?>
                    <div class="card mt-4">
                        <div class="card-header">
                            <div class="card-title">
                                <strong><?php echo e($year->year); ?> Past Questions</strong>
                            </div>
                            <?php $__currentLoopData = $getMyPQ; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $actionshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($key == 0 ): ?>
                                <?php
                                    $action = $actionshow->action;
                                ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-tools">
                                <span style="float:right">
                                    <?php if($subscribed == false): ?>
                                    <a href="#" class="btn btn-warning shadow unlock" id="<?php echo e($year->year); ?>" title="<?php echo e($year->year); ?>">LOCKED</a>
                                    <?php else: ?>
                                    <a href="" class="btn btn-primary shadow">ACTIVE</a>
                                    <?php endif; ?>
                                </span>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <!-- past question col -->
                                <?php $__currentLoopData = $getMyPQ; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($subscribed == false): ?>
                                    <div class="col-12 col-sm-6 col-md-2">
                                        <div class="card shadow">
                                            <div class="card-body">
                                                <img src="<?php echo e(asset('passquestions/lock.jpg')); ?>" style="width:100%">
                                            </div>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                    <div class="col-12 col-sm-6 col-md-2">
                                        <div class="card shadow">
                                            <?php if($pq->semester == '1'): ?>
                                            <span class=" badge badge-primary">First Semester</span>
                                            <?php else: ?>
                                            <span class=" badge badge-primary">Second Semester</span>
                                            <?php endif; ?>
                                            <div class="card-body">
                                            <img src="<?php echo e(asset('/storage/pastquestionImages/'.$pq->image)); ?>" style="width:100%">
                                            <span class="badge badge-dark">Course Code: <?php echo e($pq->coursecode); ?></span>
                                            </div>
                                            <div class="card-foote">
                                                <a href="<?php echo e(url('/storage/pastquestionImages/'.$pq->image)); ?>" download class="btn btn-primary w-100 shadow"><i class="fas fa-download"></i> Download</a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <?php if($subscribed == false): ?>
                        <div class="card-fooer">
                            <a href="#" class="btn btn-warning w-100 shadow unlock" id="<?php echo e($year->year); ?>" title="<?php echo e($year->year); ?>">SUBSCRIBE TO UNLOCK</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>  
        </div>
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- PQ Subscription  Modal -->
<div class="modal fade" id="unlockModal" tabindex="-1" role="dialog" aria-labelledby="unlockModal" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
        <div class="card">
            <div class="card-body">
                <div class="text-center">
                    <i class="fas fa-user-lock text-dark" style="font-size:3.0em;"></i>
                    <h6 class="text-bold mt-2">PAY TO UNLOCK YOUR <span id="modalMsg" class="text-primary"></span> PAST QUESTIONS</h6>
                    <p id="modalMsg"></p>
    
                    <div class="amtDiv">
                        <h5 class="text-bold">&#8358;200.00</h5>
                    </div>
    
                    <div class="mt-4">
                        <input type="hidden" id="userid" value="<?php echo e(Auth::user()->id); ?>">
                        <input type="hidden" id="email" value="<?php echo e(Auth::user()->email); ?>">
                        <input type="hidden" id="yearval" value="" style="display:none">
                        <script src="https://api.ravepay.co/flwv3-pug/getpaidx/api/flwpbf-inline.js"></script>
                        <button  class="btn btn-primary shadow" id="pay">PAY NOW</button>
                    </div>
                </div>
            </div>
            
                <img src="<?php echo e(asset('images/payment.jpg')); ?>" class="w-100">
            
        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\funia\resources\views/users/morepastquestion.blade.php ENDPATH**/ ?>