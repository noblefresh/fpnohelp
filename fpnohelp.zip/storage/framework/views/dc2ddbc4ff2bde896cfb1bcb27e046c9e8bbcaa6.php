  <nav class="main-header navbar navbar-expand navbar-pimary nabar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link text-dark" data-widget="" href="<?php echo e(route('home')); ?>" role="button"><i class="fas fa-chevron-left"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('home')); ?>" class="nav-link text-dark">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('userblog')); ?>" class="nav-link text-dark">Info</a>
      </li>
    </ul>


    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      
      <li class="nav-item dropdown">
        <a class="nav-link text-dark" data-toggle="dropdown" id="profile" href="#">
          <i class="fas fa-user"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" id="showprofile" >
          <span class="dropdown-item dropdown-header">Account</span>
          <div class="dropdown-divider"></div>
          <a href="<?php echo e(route('userprofile')); ?>" class="dropdown-item">
            <i class="fas fa-user mr-2"></i> Profile
          </a>
          <div class="dropdown-divider"></div>
          <a href="<?php echo e(route('logout')); ?>"
                  onclick="event.preventDefault();
                  document.getElementById('logout-form').submit();" class="dropdown-item">
            <i class="fas fa-power-off mr-2"></i> Sign out
          </a>
        </div>
      </li>
      
    </ul>
  </nav><?php /**PATH C:\xampp\htdocs\fpnohelp\resources\views/layouts/topnav.blade.php ENDPATH**/ ?>